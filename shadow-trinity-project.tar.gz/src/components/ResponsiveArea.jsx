import React from 'react';

/**
 * The ResponseArea component displays Echo Twin's responses
 * @param {Object} props - Component props
 * @param {string} props.response - The text response from Echo Twin
 */
const ResponseArea = ({ response }) => {
  return (
    <div className="response-area">
      <p>{response}</p>
    </div>
  );
};

export default ResponseArea;