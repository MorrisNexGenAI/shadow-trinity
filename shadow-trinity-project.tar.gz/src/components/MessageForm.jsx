import React, { useState } from 'react';

/**
 * The MessageForm component allows users to input messages
 * @param {Object} props - Component props
 * @param {Function} props.onMessageSubmit - Callback function when a message is submitted
 */
const MessageForm = ({ onMessageSubmit }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() === '') return;
    
    onMessageSubmit(message);
    setMessage('');
  };

  return (
    <form className="message-form" onSubmit={handleSubmit}>
      <input
        type="text"
        className="message-input"
        placeholder="Enter your message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button type="submit" className="submit-button">SEND</button>
    </form>
  );
};

export default MessageForm;