import React from 'react';

/**
 * The EchoTwin component for Shadow OS
 * Represents the AI entity with its avatar and name
 */
const EchoTwin = () => {
  return (
    <div className="twin-container">
      <div className="echo-twin-avatar"></div>
      <h2>ECHO TWIN</h2>
    </div>
  );
};

export default EchoTwin;