import { useState } from 'react';
import './App.css';

// Import components
import Header from './components/header';
import EchoTwin from './components/Echotwin';
import ResponseArea from './components/ResponsiveArea';
import MessageForm from './components/MessageForm';

// Import the emotional analyzer utility
import { analyzeEmotionAndRespond } from './utils/emotionalAnalyzer.js';

/**
 * The main App component that composes all Shadow OS parts
 */
function App() {
  // Initial state with a welcoming message
  const [response, setResponse] = useState('Echo Twin ready. How are you feeling today?');

  /**
   * Handles message submission from the MessageForm component
   * Analyzes the message and updates the response state
   * @param {string} message - The user's message
   */
  const handleMessageSubmit = (message) => {
    const newResponse = analyzeEmotionAndRespond(message);
    setResponse(newResponse);
  };

  return (
    <div className="shadow-os-container">
      {/* Header component with title and version */}
      <Header />
      
      {/* EchoTwin component with avatar and name */}
      <EchoTwin />
      
      {/* ResponseArea component to display AI responses */}
      <ResponseArea response={response} />
      
      {/* MessageForm component for user input */}
      <MessageForm onMessageSubmit={handleMessageSubmit} />
      
      {/* Footer section */}
      <div className="footer">
        © 2025 SHADOW OS | ECHO TWIN PROTOCOL
      </div>
    </div>
  );
}

export default App;
