import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0', // Required for Replit - binds to all network interfaces
    port: 5000,
    strictPort: true,
    hmr: {
      clientPort: 443, // Required for Replit
      host: '0.0.0.0'
    },
    cors: true,
    // Explicitly allow all hosts - required for Replit
    allowedHosts: ['localhost', '.replit.dev', '.repl.co', '.replit.app'],
  },
  // Define base to ensure assets load correctly
  base: './'
});